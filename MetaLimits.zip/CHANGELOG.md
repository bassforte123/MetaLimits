1.0.7 - The Gundead's Affinity added.

1.0.6 - Typo fixed.

1.0.5 - Super Tonic unlock moved to the Tonic line and Hegemony requirement raised to 500

1.0.4 - Changelog added.

1.0.3 - Typoes in Readme fixed.

1.0.2 - Indentation in Readme fixed.

1.0.1 - Intro freeze bug fixed.

1.0.0 - Initial release.