2.1.0 - Added new ultimate unlock under Dungeon Affinity.

2.0.2 - Fixed the synergy fuse perk not working and a minor typo in the descriptions.

2.0.1 - Added an increased difficulty setting to Boss DPS Cap.

2.0.0 - Major overhaul.  Many additional NPCs included to the list.
		Gundead's Affinity replaced with Ser Manuel.  
		Bullet Affinity now gives blanks.  
		Coolness bonus moved to Gunslinger Affinity.
		Old Gunslinger Affinity removed.
		Curse removal Affinity moved to Daisuke.
		Fixed bug that caused the Advanced Dragun Affinity to make shops only sell S ranked items.

1.0.7 - The Gundead's Affinity added.

1.0.6 - Typo fixed.

1.0.5 - Super Tonic unlock moved to the Tonic line and Hegemony requirement raised to 500

1.0.4 - Changelog added.

1.0.3 - Typoes in Readme fixed.

1.0.2 - Indentation in Readme fixed.

1.0.1 - Intro freeze bug fixed.

1.0.0 - Initial release.